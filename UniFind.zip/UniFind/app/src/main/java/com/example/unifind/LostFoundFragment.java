package com.example.unifind;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.unifind.models.LostFoundItem;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import io.realm.Realm;
import io.realm.RealmResults;

public class LostFoundFragment extends Fragment {

    private LinearLayout lostFoundContainer;
    private Realm realm;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_lost_found, container, false);
        lostFoundContainer = view.findViewById(R.id.lostFoundContainer);
        realm = Realm.getDefaultInstance();

        checkAndPopulateDummyData();
        loadItems();

        return view;
    }

    private void checkAndPopulateDummyData() {
        if (realm.where(LostFoundItem.class).count() == 0) {
            realm.executeTransaction(r -> {
                LostFoundItem i1 = r.createObject(LostFoundItem.class, "lf1");
                i1.setTitle("iPhone 13 Pro");
                i1.setType("lost");
                i1.setLocation("Bibliothèque - 2ème étage");
                i1.setDescription("Coque bleue, petite fissure sur l'écran");
                i1.setDateLostOrFound(System.currentTimeMillis());

                LostFoundItem i2 = r.createObject(LostFoundItem.class, "lf2");
                i2.setTitle("Sac à dos noir");
                i2.setType("found");
                i2.setLocation("Bâtiment d'ingénierie");
                i2.setDescription("Contient des cahiers et un ordinateur portable");
                i2.setDateLostOrFound(System.currentTimeMillis());

                LostFoundItem i3 = r.createObject(LostFoundItem.class, "lf3");
                i3.setTitle("Carte d'étudiant");
                i3.setType("lost");
                i3.setLocation("Zone cafétéria");
                i3.setDescription("Nom: Ahmed M.");
                i3.setDateLostOrFound(System.currentTimeMillis());
            });
        }
    }

    private void loadItems() {
        lostFoundContainer.removeAllViews();
        RealmResults<LostFoundItem> items = realm.where(LostFoundItem.class).findAll();

        SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy", Locale.FRANCE);

        for (LostFoundItem item : items) {
            View itemView = LayoutInflater.from(getContext()).inflate(R.layout.item_lost_found, lostFoundContainer, false);

            LinearLayout card = itemView.findViewById(R.id.cardContainer);
            TextView status = itemView.findViewById(R.id.statusBadge);
            TextView title = itemView.findViewById(R.id.itemName);
            TextView location = itemView.findViewById(R.id.itemLocation);
            TextView date = itemView.findViewById(R.id.itemDate);
            TextView description = itemView.findViewById(R.id.itemDescription);
            Button action = itemView.findViewById(R.id.actionButton);

            title.setText(item.getTitle());
            location.setText(item.getLocation());
            date.setText(sdf.format(new Date(item.getDateLostOrFound())));
            description.setText(item.getDescription());

            if ("lost".equals(item.getType())) {
                card.setBackgroundResource(R.drawable.bg_lost_card);
                status.setText("PERDU");
                status.setBackgroundResource(R.drawable.bg_badge_lost);
                action.setText("Contacter");
            } else {
                card.setBackgroundResource(R.drawable.bg_found_card);
                status.setText("TROUVÉ");
                status.setBackgroundResource(R.drawable.bg_badge_found);
                action.setText("C'est le mien !");
            }

            lostFoundContainer.addView(itemView);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (realm != null) {
            realm.close();
        }
    }
}