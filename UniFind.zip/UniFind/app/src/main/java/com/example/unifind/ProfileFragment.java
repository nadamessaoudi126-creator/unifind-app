package com.example.unifind;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ProfileFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        // Make list items clickable
        setupClickListeners(view);

        return view;
    }

    private void setupClickListeners(View view) {
        // Find the parent containers of the items and set click listeners
        // Note: In fragment_profile.xml, these are the LinearLayouts containing the icons and text

        // Mes Annonces (This is usually the first item in the list)
        View mesAnnonces = view.findViewWithTag("item_annonces"); 
        // If you haven't set tags, we can find them by their structure or add IDs to the layout.
        // Let's assume we add IDs for clarity.
        
        View optAnnonces = view.findViewById(R.id.optAnnonces);
        if (optAnnonces != null) {
            optAnnonces.setOnClickListener(v -> Toast.makeText(getContext(), "Mes Annonces cliqué", Toast.LENGTH_SHORT).show());
        }

        View optFavoris = view.findViewById(R.id.optFavoris);
        if (optFavoris != null) {
            optFavoris.setOnClickListener(v -> Toast.makeText(getContext(), "Favoris cliqué", Toast.LENGTH_SHORT).show());
        }

        View optMessages = view.findViewById(R.id.optMessages);
        if (optMessages != null) {
            optMessages.setOnClickListener(v -> Toast.makeText(getContext(), "Messages cliqué", Toast.LENGTH_SHORT).show());
        }
    }
}