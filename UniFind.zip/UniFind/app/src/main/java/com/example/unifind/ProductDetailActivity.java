package com.example.unifind;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.unifind.models.Listing;

import io.realm.Realm;

public class ProductDetailActivity extends AppCompatActivity {

    public static final String EXTRA_PRODUCT_ID = "extra_product_id";
    private Realm realm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);

        realm = Realm.getDefaultInstance();
        String productId = getIntent().getStringExtra(EXTRA_PRODUCT_ID);

        if (productId != null) {
            Listing listing = realm.where(Listing.class).equalTo("id", productId).findFirst();
            if (listing != null) {
                populateUI(listing);
            }
        }

        findViewById(R.id.backButton).setOnClickListener(v -> finish());
    }

    private void populateUI(Listing listing) {
        TextView title = findViewById(R.id.detailTitle);
        TextView price = findViewById(R.id.detailPrice);
        TextView condition = findViewById(R.id.detailCondition);
        TextView location = findViewById(R.id.detailLocation);
        TextView description = findViewById(R.id.detailDescription);

        title.setText(listing.getTitle());
        price.setText(listing.getPrice() == 0 ? "GRATUIT" : listing.getPrice() + " DH");
        condition.setText("✨ " + listing.getCondition());
        location.setText("📍 " + listing.getLocation());
        
        if (listing.getDescription() != null && !listing.getDescription().isEmpty()) {
            description.setText(listing.getDescription());
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (realm != null) {
            realm.close();
        }
    }
}