package com.example.unifind;

import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.unifind.models.Listing;

import io.realm.Realm;

public class MainActivity extends AppCompatActivity {

    private LinearLayout navMarket, navLostFound, navPost, navMyItems, navProfile;
    private TextView navMarketText, navLostFoundText, navPostText, navMyItemsText, navProfileText;
    private Realm realm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.relative_layout);

        realm = Realm.getDefaultInstance();

        // Find views
        navMarket = findViewById(R.id.navMarket);
        navLostFound = findViewById(R.id.navLostFound);
        navPost = findViewById(R.id.navPost);
        navMyItems = findViewById(R.id.navMyItems);
        navProfile = findViewById(R.id.navProfile);

        navMarketText = findViewById(R.id.navMarketText);
        navLostFoundText = findViewById(R.id.navLostFoundText);
        navPostText = findViewById(R.id.navPostText);
        navMyItemsText = findViewById(R.id.navMyItemsText);
        navProfileText = findViewById(R.id.navProfileText);

        // Set click listeners
        navMarket.setOnClickListener(v -> selectTab(0));
        navLostFound.setOnClickListener(v -> selectTab(1));
        navPost.setOnClickListener(v -> selectTab(2));
        navMyItems.setOnClickListener(v -> selectTab(3));
        navProfile.setOnClickListener(v -> selectTab(4));

        // Populate with dummy data if Realm is empty
        checkAndPopulateDummyData();

        // Select Market tab by default
        if (savedInstanceState == null) {
            selectTab(0);
        }
    }

    private void checkAndPopulateDummyData() {
        if (realm.where(Listing.class).count() == 0) {
            realm.executeTransaction(r -> {
                Listing l1 = r.createObject(Listing.class, "1");
                l1.setTitle("Veste d'hiver");
                l1.setPrice(150);
                l1.setCondition("NEUF");
                l1.setLocation("Résidences");
                l1.setDescription("Veste chaude pour l'hiver, taille M, couleur bleue.");

                Listing l2 = r.createObject(Listing.class, "2");
                l2.setTitle("Manuel Physique");
                l2.setPrice(80);
                l2.setCondition("BON ÉTAT");
                l2.setLocation("Bibliothèque");
                l2.setDescription("Manuel de physique pour la première année, quelques annotations.");

                Listing l3 = r.createObject(Listing.class, "3");
                l3.setTitle("Calculatrice TI-84");
                l3.setPrice(250);
                l3.setCondition("COMME NEUF");
                l3.setLocation("Cafétéria");
                l3.setDescription("Calculatrice graphique TI-84 Plus, très peu utilisée.");

                Listing l4 = r.createObject(Listing.class, "4");
                l4.setTitle("Sac à dos");
                l4.setPrice(0);
                l4.setCondition("GRATUIT");
                l4.setLocation("Bâtiment d'ingénierie");
                l4.setDescription("Sac à dos noir en bon état, à donner.");
            });
        }
    }

    private void selectTab(int tabIndex) {
        // Reset all tabs to inactive color
        resetNavColors();

        Fragment selectedFragment = null;

        // Activate selected tab and choose fragment
        switch (tabIndex) {
            case 0: // Market
                navMarketText.setTextColor(getColor(R.color.uir_blue));
                navMarketText.setTypeface(null, android.graphics.Typeface.BOLD);
                selectedFragment = new MarketFragment();
                break;
            case 1: // Lost & Found
                navLostFoundText.setTextColor(getColor(R.color.uir_blue));
                navLostFoundText.setTypeface(null, android.graphics.Typeface.BOLD);
                selectedFragment = new LostFoundFragment();
                break;
            case 2: // Post
                navPostText.setTextColor(getColor(R.color.uir_blue));
                navPostText.setTypeface(null, android.graphics.Typeface.BOLD);
                selectedFragment = new PostFragment();
                break;
            case 3: // My Items
                navMyItemsText.setTextColor(getColor(R.color.uir_blue));
                navMyItemsText.setTypeface(null, android.graphics.Typeface.BOLD);
                selectedFragment = new MyItemsFragment();
                break;
            case 4: // Profile
                navProfileText.setTextColor(getColor(R.color.uir_blue));
                navProfileText.setTypeface(null, android.graphics.Typeface.BOLD);
                selectedFragment = new ProfileFragment();
                break;
        }

        if (selectedFragment != null) {
            replaceFragment(selectedFragment);
        }
    }

    private void resetNavColors() {
        navMarketText.setTextColor(getColor(R.color.text_gray));
        navMarketText.setTypeface(null, android.graphics.Typeface.NORMAL);

        navLostFoundText.setTextColor(getColor(R.color.text_gray));
        navLostFoundText.setTypeface(null, android.graphics.Typeface.NORMAL);

        navPostText.setTextColor(getColor(R.color.text_gray));
        navPostText.setTypeface(null, android.graphics.Typeface.NORMAL);

        navMyItemsText.setTextColor(getColor(R.color.text_gray));
        navMyItemsText.setTypeface(null, android.graphics.Typeface.NORMAL);

        navProfileText.setTextColor(getColor(R.color.text_gray));
        navProfileText.setTypeface(null, android.graphics.Typeface.NORMAL);
    }

    private void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragmentContainer, fragment);
        fragmentTransaction.commit();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (realm != null) {
            realm.close();
        }
    }
}