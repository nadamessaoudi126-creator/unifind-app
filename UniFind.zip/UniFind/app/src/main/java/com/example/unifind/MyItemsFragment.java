package com.example.unifind;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.unifind.models.Listing;

import io.realm.Realm;
import io.realm.RealmResults;

public class MyItemsFragment extends Fragment {

    private GridLayout myItemsGrid;
    private TextView activeCountText, soldCountText;
    private Realm realm;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_my_items, container, false);
        
        myItemsGrid = view.findViewById(R.id.myItemsGrid);
        activeCountText = view.findViewById(R.id.activeCountText);
        soldCountText = view.findViewById(R.id.soldCountText);
        
        realm = Realm.getDefaultInstance();
        
        loadMyItems();
        
        return view;
    }

    private void loadMyItems() {
        myItemsGrid.removeAllViews();
        
        // In a real app, you would filter by the current user's ID
        // For this demo, we'll show all items to demonstrate the UI
        RealmResults<Listing> listings = realm.where(Listing.class).findAll();
        
        long activeCount = realm.where(Listing.class).equalTo("status", "available").count();
        long soldCount = realm.where(Listing.class).equalTo("status", "sold").count();
        
        activeCountText.setText(String.valueOf(activeCount));
        soldCountText.setText(String.valueOf(soldCount));

        for (Listing listing : listings) {
            View productView = LayoutInflater.from(getContext()).inflate(R.layout.item_product_card, myItemsGrid, false);
            
            TextView title = productView.findViewById(R.id.productTitle);
            TextView price = productView.findViewById(R.id.productPrice);
            TextView location = productView.findViewById(R.id.productLocation);
            TextView condition = productView.findViewById(R.id.conditionBadge);
            
            title.setText(listing.getTitle());
            price.setText(listing.getPrice() == 0 ? "GRATUIT" : listing.getPrice() + " DH");
            location.setText(listing.getLocation());
            condition.setText(listing.getCondition());

            // Click listener to open detail
            String productId = listing.getId();
            productView.setOnClickListener(v -> {
                Intent intent = new Intent(getActivity(), ProductDetailActivity.class);
                intent.putExtra(ProductDetailActivity.EXTRA_PRODUCT_ID, productId);
                startActivity(intent);
            });

            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = 0;
            params.height = GridLayout.LayoutParams.WRAP_CONTENT;
            params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            productView.setLayoutParams(params);

            myItemsGrid.addView(productView);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (realm != null) {
            realm.close();
        }
    }
}