package com.example.unifind;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.unifind.models.Listing;

import java.util.UUID;

import io.realm.Realm;

public class PostFragment extends Fragment {

    private EditText editTitre, editPrix, editDescription;
    private Spinner spinnerCategorie, spinnerEtat;
    private Button btnPublier;
    private Realm realm;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_post, container, false);
        
        realm = Realm.getDefaultInstance();
        
        editTitre = view.findViewById(R.id.editTitre);
        editPrix = view.findViewById(R.id.editPrix);
        editDescription = view.findViewById(R.id.editDescription);
        spinnerCategorie = view.findViewById(R.id.spinnerCategorie);
        spinnerEtat = view.findViewById(R.id.spinnerEtat);
        btnPublier = view.findViewById(R.id.btnPublier);

        setupSpinners();
        
        btnPublier.setOnClickListener(v -> publierArticle());

        return view;
    }

    private void setupSpinners() {
        String[] categories = {"Vêtements", "Livres", "Électronique", "Meubles", "Sport", "Autre"};
        ArrayAdapter<String> catAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_item, categories);
        catAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategorie.setAdapter(catAdapter);

        String[] etats = {"Neuf", "Comme neuf", "Bon état", "État correct"};
        ArrayAdapter<String> etatAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_item, etats);
        etatAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerEtat.setAdapter(etatAdapter);
    }

    private void publierArticle() {
        String titre = editTitre.getText().toString().trim();
        String prixStr = editPrix.getText().toString().trim();
        String description = editDescription.getText().toString().trim();
        String categorie = spinnerCategorie.getSelectedItem().toString();
        String etat = spinnerEtat.getSelectedItem().toString().toUpperCase();

        if (titre.isEmpty() || prixStr.isEmpty()) {
            Toast.makeText(getContext(), "Veuillez remplir au moins le titre et le prix", Toast.LENGTH_SHORT).show();
            return;
        }

        double prix = Double.parseDouble(prixStr);

        realm.executeTransaction(r -> {
            Listing listing = r.createObject(Listing.class, UUID.randomUUID().toString());
            listing.setTitle(titre);
            listing.setPrice(prix);
            listing.setDescription(description);
            listing.setCategory(categorie);
            listing.setCondition(etat);
            listing.setLocation("Campus"); // Default for now
            listing.setCreatedAt(System.currentTimeMillis());
            listing.setStatus("available");
        });

        Toast.makeText(getContext(), "Article publié avec succès !", Toast.LENGTH_SHORT).show();
        
        // Clear fields
        editTitre.setText("");
        editPrix.setText("");
        editDescription.setText("");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (realm != null) {
            realm.close();
        }
    }
}