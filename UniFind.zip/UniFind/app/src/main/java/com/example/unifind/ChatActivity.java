package com.example.unifind;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.unifind.models.message;

import java.util.UUID;

import io.realm.Realm;
import io.realm.RealmResults;
import io.realm.Sort;

public class ChatActivity extends AppCompatActivity {

    public static final String EXTRA_USER_ID = "extra_user_id";
    public static final String EXTRA_USER_NAME = "extra_user_name";

    private String otherUserId;
    private String otherUserName;
    
    private RecyclerView chatRecyclerView;
    private EditText messageInput;
    private ImageButton sendButton;
    private TextView chatUserName;
    
    private Realm realm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        realm = Realm.getDefaultInstance();
        
        otherUserId = getIntent().getStringExtra(EXTRA_USER_ID);
        otherUserName = getIntent().getStringExtra(EXTRA_USER_NAME);

        chatUserName = findViewById(R.id.chatUserName);
        chatUserName.setText(otherUserName != null ? otherUserName : "Utilisateur");

        findViewById(R.id.backButton).setOnClickListener(v -> finish());

        chatRecyclerView = findViewById(R.id.chatRecyclerView);
        messageInput = findViewById(R.id.messageInput);
        sendButton = findViewById(R.id.sendButton);

        chatRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        
        // Setup adapter and load messages
        loadMessages();

        sendButton.setOnClickListener(v -> sendMessage());
    }

    private void loadMessages() {
        // In a real app, you would filter messages between current user and otherUserId
        RealmResults<message> messages = realm.where(message.class)
                .findAll()
                .sort("sentAt", Sort.ASCENDING);
        
        // Simple implementation: for now we just show all messages as a placeholder
        // In a real app, create a ChatAdapter
    }

    private void sendMessage() {
        String text = messageInput.getText().toString().trim();
        if (text.isEmpty()) return;

        realm.executeTransaction(r -> {
            message msg = r.createObject(message.class, UUID.randomUUID().toString());
            msg.setContent(text);
            msg.setSentAt(System.currentTimeMillis());
            msg.setSenderId("current_user_id"); // Replace with actual current user ID
            msg.setReceiverId(otherUserId);
        });

        messageInput.setText("");
        Toast.makeText(this, "Message envoyé", Toast.LENGTH_SHORT).show();
        loadMessages();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (realm != null) {
            realm.close();
        }
    }
}